import { useRoutes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Profil from "./pages/Profil";
import Kontakta from "./pages/Kontakta";
import OmMig from "./pages/OmMig";
import CrossMedia from "./pages/CrossMedia";
import GrafiskProduktion from "./pages/GrafiskProduktion";
import ThreeDPrint from "./pages/ThreeDPrint";
import UxUiDesign from "./pages/UxUiDesign";
import { LanguageProvider } from "./context/LanguageContext";
import "./App.css";

const Routes = () => {
  return useRoutes([
    { path: "/", element: <Home /> },
    { path: "/crossmedia/:id", element: <CrossMedia /> },
    { path: "/grafiskproduktion/:id", element: <GrafiskProduktion /> },
    { path: "/threedprint/:id", element: <ThreeDPrint /> },
    { path: "/uxuidesign/:id", element: <UxUiDesign /> },
    { path: "/profil", element: <Profil /> },
    { path: "/kontakta", element: <Kontakta /> },
    { path: "/ommig", element: <OmMig /> },
  ]);
};

const App = () => (
  <LanguageProvider>
    <Navbar />
    <Routes />
  </LanguageProvider>
);

export default App;
