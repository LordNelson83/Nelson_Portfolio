import bild1 from "../assets/images/bild1.png";
import print2 from "../assets/images/print2.png";
import d3print from "../assets/images/3dprinting.png";
import uxdesigner from "../assets/images/uxdesigner.png";

export const productsId = [
  {
    id: 1,
    name: { ES: "Cross Media Design", EN: "Cross Media Design", SV: "Cross Media Design" },
    route: "crossmedia",
    image: bild1,
    tags: ["Photoshop", "Illustrator", "InDesign"],
  },
  {
    id: 2,
    name: { ES: "Mis Proyectos", EN: "My Projects", SV: "Mina Projekt" },
    route: "grafiskproduktion",
    image: print2,
    tags: ["Figma", "React", "UX Research"],
  },
  {
    id: 3,
    name: { ES: "3D Print & Diseño", EN: "3D Print & Design", SV: "3D Print & Design" },
    route: "threedprint",
    image: d3print,
    tags: ["Shapr3D", "3D Printing"],
  },
  {
    id: 4,
    name: { ES: "UX/UI & Frontend", EN: "UX/UI & Frontend", SV: "UX/UI & Frontend" },
    route: "uxuidesign",
    image: uxdesigner,
    tags: ["Figma", "React", "Discovery"],
  },
];
