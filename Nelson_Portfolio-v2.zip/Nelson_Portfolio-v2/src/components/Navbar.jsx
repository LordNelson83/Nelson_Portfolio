import { useState, useEffect } from "react";
import { NavLink, Link } from "react-router-dom";
import { useLang } from "../context/LanguageContext";
import nptLogo from "../assets/images2/npt.png";
import "./Navbar.css";

const Navbar = () => {
  const { lang, setLang, t } = useLang();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <nav className={`navbar ${scrolled ? "navbar--scrolled" : ""}`}>
      <Link to="/" className="navbar__logo" onClick={closeMenu}>
        <img src={nptLogo} alt="NPT Logo" />
      </Link>

      {/* Desktop links */}
      <div className="navbar__links">
        <NavLink to="/ommig" className={({ isActive }) => isActive ? "nav-link active-link" : "nav-link"}>
          {t.nav.about}
        </NavLink>
        <NavLink to="/profil" className={({ isActive }) => isActive ? "nav-link active-link" : "nav-link"}>
          {t.nav.work}
        </NavLink>
        <NavLink to="/kontakta" className={({ isActive }) => isActive ? "nav-link active-link" : "nav-link"}>
          {t.nav.contact}
        </NavLink>
      </div>

      {/* Language switcher */}
      <div className="navbar__lang">
        {["ES", "EN", "SV"].map((l) => (
          <button
            key={l}
            className={`lang-btn ${lang === l ? "lang-btn--active" : ""}`}
            onClick={() => setLang(l)}
          >
            {l}
          </button>
        ))}
      </div>

      {/* Hamburger */}
      <button
        className={`navbar__hamburger ${menuOpen ? "open" : ""}`}
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Toggle menu"
      >
        <span />
        <span />
        <span />
      </button>

      {/* Mobile menu */}
      <div className={`navbar__mobile ${menuOpen ? "navbar__mobile--open" : ""}`}>
        <NavLink to="/ommig" className="mobile-link" onClick={closeMenu}>{t.nav.about}</NavLink>
        <NavLink to="/profil" className="mobile-link" onClick={closeMenu}>{t.nav.work}</NavLink>
        <NavLink to="/kontakta" className="mobile-link" onClick={closeMenu}>{t.nav.contact}</NavLink>
        <div className="mobile-lang">
          {["ES", "EN", "SV"].map((l) => (
            <button
              key={l}
              className={`lang-btn ${lang === l ? "lang-btn--active" : ""}`}
              onClick={() => { setLang(l); closeMenu(); }}
            >
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Overlay */}
      {menuOpen && <div className="navbar__overlay" onClick={closeMenu} />}
    </nav>
  );
};

export default Navbar;
