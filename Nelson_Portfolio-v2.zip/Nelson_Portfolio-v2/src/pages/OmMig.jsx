import React from "react";
import "../pagesCSS/OmMig.css";
import me from "../assets/images2/me.png";
import Acrobat from "../assets/images2/Acrobat.png";
import CSS from "../assets/images2/CSS.png";
import Figma from "../assets/images2/Figma.png";
import Github from "../assets/images2/Github.png";
import HTLM from "../assets/images2/HTLM.png";
import Illustrator from "../assets/images2/Illustrator.png";
import Indesign from "../assets/images2/Indesign.png";
import Javascript from "../assets/images2/Javascript.png";
import Mailchimp from "../assets/images2/Mailchimp.png";
import microsoft_netlify from "../assets/images2/microsoft_netlify.png";
import Photoshop from "../assets/images2/Photoshop.png";
import Shapr3d from "../assets/images2/Shapr3d.png";
import ReactImg from "../assets/images2/React.png";
import { useLang } from "../context/LanguageContext";

const skills = [
  { src: Figma, label: "Figma" },
  { src: ReactImg, label: "React" },
  { src: Javascript, label: "JavaScript" },
  { src: HTLM, label: "HTML" },
  { src: CSS, label: "CSS" },
  { src: Github, label: "GitHub" },
  { src: Photoshop, label: "Photoshop" },
  { src: Illustrator, label: "Illustrator" },
  { src: Indesign, label: "InDesign" },
  { src: Acrobat, label: "Acrobat" },
  { src: Shapr3d, label: "Shapr3D" },
  { src: Mailchimp, label: "Mailchimp" },
  { src: microsoft_netlify, label: "Netlify" },
];

const OmMig = () => {
  const { t } = useLang();

  return (
    <div className="about-container">
      {/* Left */}
      <div className="about-left">
        <h1 className="about-title">
          {t.about.title.split("\n").map((line, i) => (
            <span key={i}>{line}<br /></span>
          ))}
        </h1>
        <h2 className="about-subtitle">{t.about.subtitle}</h2>
        <div className="about-bio">
          {t.about.bio.split("\n\n").map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>

        <div className="about-skills-section">
          <h3 className="about-skills-label">{t.about.skills}</h3>
          <div className="about-skills-grid">
            {skills.map((s) => (
              <div className="skill-chip" key={s.label}>
                <img src={s.src} alt={s.label} />
                <span>{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right */}
      <div className="about-right">
        <div className="about-photo-frame">
          <div className="about-photo-bg" />
          <div className="about-photo-circle">
            <img src={me} alt="Nelson Peña" className="about-me-img" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default OmMig;
