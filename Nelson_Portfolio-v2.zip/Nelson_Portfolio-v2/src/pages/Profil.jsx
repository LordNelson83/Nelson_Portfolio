import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { productsId } from "../data/productsId";
import { useLang } from "../context/LanguageContext";
import "../pagesCSS/profil.css";

const Profil = () => {
  const { lang, t } = useLang();
  const [products, setProducts] = useState([]);
  const [hovered, setHovered] = useState(null);

  useEffect(() => {
    setProducts(productsId);
  }, []);

  return (
    <div className="portfolio-container">
      <div className="portfolio-title-vertical">{t.work.title}</div>

      <div className="portfolio-content">
        <ul className="portfolio-products">
          {products.map((product) => (
            <li
              className={`product-item ${hovered === product.id ? "product-item--hovered" : ""}`}
              key={product.id}
              onMouseEnter={() => setHovered(product.id)}
              onMouseLeave={() => setHovered(null)}
            >
              <p className="product-name">{product.name[lang]}</p>
              <Link to={`/${product.route}/${product.id}`}>
                <div className="product-img-wrap">
                  <img
                    src={product.image}
                    alt={product.name[lang]}
                    className="product-image"
                  />
                  <div className="product-overlay">
                    <span>{t.work.viewCase} →</span>
                  </div>
                </div>
              </Link>
              <div className="product-tags">
                {product.tags.map((tag) => (
                  <span key={tag} className="product-tag">{tag}</span>
                ))}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Profil;
