import "../pagesCSS/Home.css";
import mustang from "../assets/images2/mustang.png";
import { useLang } from "../context/LanguageContext";
import { Link } from "react-router-dom";

const Home = () => {
  const { t } = useLang();

  return (
    <div className="home-container">
      <div className="home-text">
        <span className="home-role">{t.home.role}</span>
        <h2 className="home-name">Nelson Peña</h2>
        <h1 className="home-title">Portfölj</h1>
        <p className="home-intro">{t.home.intro}</p>
        <div className="home-ctas">
          <Link to="/profil" className="btn btn--primary">{t.home.cta}</Link>
          <Link to="/kontakta" className="btn btn--outline">{t.home.ctaContact}</Link>
        </div>
      </div>
      <div className="home-image">
        <img className="mustang" src={mustang} alt="Mustang car" />
        <div className="home-image__accent" />
      </div>
    </div>
  );
};

export default Home;
