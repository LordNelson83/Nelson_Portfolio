import mustang2 from "../assets/images2/mustang2.png";
import mustang1 from "../assets/images2/mustang1.png";
import "../pagesCSS/Kontakta.css";
import { useLang } from "../context/LanguageContext";

const Kontakta = () => {
  const { t } = useLang();

  const links = [
    {
      label: t.contact.linkedin,
      icon: "in",
      href: "https://www.linkedin.com/in/nelson-pe%C3%B1a-21881412a/",
      external: true,
    },
    {
      label: t.contact.github,
      icon: "gh",
      href: "https://github.com/LordNelson83",
      external: true,
    },
    {
      label: t.contact.cv,
      icon: "cv",
      href: "/CV_Nelson_Pena.pdf",
      download: true,
    },
    {
      label: "nelsonpenna83@gmail.com",
      icon: "✉",
      href: "mailto:nelsonpenna83@gmail.com",
    },
  ];

  return (
    <div className="contact-page">
      <div className="contact-content">
        <h1 className="contact-title">{t.contact.title}</h1>
        <p className="contact-subtitle">{t.contact.subtitle}</p>

        <div className="contact-links">
          {links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="contact-link-item"
              target={link.external ? "_blank" : undefined}
              rel={link.external ? "noopener noreferrer" : undefined}
              download={link.download ? link.label : undefined}
            >
              <span className="contact-link-icon">{link.icon}</span>
              <span className="contact-link-label">{link.label}</span>
              <span className="contact-link-arrow">→</span>
            </a>
          ))}
        </div>
      </div>

      <div className="contact-visual">
        <img src={mustang1} alt="car" className="contact-car contact-car--1" />
        <img src={mustang2} alt="car" className="contact-car contact-car--2" />
      </div>
    </div>
  );
};

export default Kontakta;
