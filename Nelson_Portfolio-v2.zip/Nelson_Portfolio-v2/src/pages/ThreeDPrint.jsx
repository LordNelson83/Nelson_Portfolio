import { useParams, Link } from "react-router-dom";
import productDetail from "../data/productDetail";
import { useLang } from "../context/LanguageContext";
import "../pagesCSS/CaseStudy.css";

const ThreeDPrint = () => {
  const { id } = useParams();
  const { t } = useLang();
  const product = productDetail.find((p) => p.id === parseInt(id));

  if (!product) return <div className="cs-not-found">Project not found.</div>;

  return (
    <div className="cs-container">
      <Link to="/profil" className="cs-back">{t.caseStudy.backBtn}</Link>
      <header className="cs-header">
        <h1 className="cs-title">{product.name}</h1>
      </header>
      {product.experiences?.map((exp, i) => (
        <section key={i} className="cs-section">
          <div className="cs-meta">
            <span className="cs-year">{exp.year}</span>
            <span className="cs-school">{exp.school}</span>
          </div>
          <p className="cs-description">{exp.description}</p>
          {exp.images?.length > 0 && (
            <div className="cs-images">
              {exp.images.map((img, j) => (
                <img key={j} src={img} alt={exp.school} className="cs-img" />
              ))}
            </div>
          )}
          {exp.links?.length > 0 && (
            <div className="cs-links">
              {exp.links.map((link) => (
                <a key={link.label} href={link.url} target="_blank" rel="noopener noreferrer" className="cs-link-btn">
                  {link.label} →
                </a>
              ))}
            </div>
          )}
        </section>
      ))}
      {product.links?.length > 0 && (
        <div className="cs-global-links">
          {product.links.map((link) => (
            <a key={link.label} href={link.url} target="_blank" rel="noopener noreferrer" className="cs-link-btn">
              {link.label} →
            </a>
          ))}
        </div>
      )}
    </div>
  );
};

export default ThreeDPrint;
