import { createContext, useContext, useState } from "react";

const LanguageContext = createContext();

export const translations = {
  ES: {
    nav: {
      about: "Sobre mí",
      work: "360° Design",
      contact: "Contacto",
    },
    home: {
      role: "Senior Product Designer · UX/UI · Frontend",
      intro:
        "Combino product discovery, diseño de sistemas y desarrollo frontend para crear experiencias digitales que generan impacto real.",
      cta: "Ver proyectos",
      ctaContact: "Contactar",
    },
    about: {
      title: "Hola,\nsoy Nelson",
      subtitle: "Diseñador multidisciplinar: Cross Media, 3D, UX/UI & Frontend",
      bio: `Soy un diseñador apasionado por crear soluciones visuales y digitales que conecten con las personas. A lo largo de los años he desempeñado múltiples roles que me han formado como un profesional flexible, curioso y orientado a resultados.\n\nTrabajo con metodologías de Product Discovery inspiradas en Marty Cagan y Teresa Torres, combinando investigación de usuarios, Opportunity Solution Trees y métricas de impacto para asegurar que cada diseño resuelva problemas reales.\n\nFuera del trabajo me mantengo activo nadando, y mi familia es mi mayor fuente de inspiración. Mis colegas me describen como social, comprometido y siempre dispuesto a colaborar.`,
      skills: "Herramientas & Skills",
    },
    work: {
      title: "360° Design",
      viewCase: "Ver caso de estudio",
    },
    contact: {
      title: "¡Hablemos!",
      subtitle:
        "Si tienes preguntas, propuestas o simplemente quieres saludar, no dudes en contactarme.",
      linkedin: "LinkedIn",
      github: "GitHub",
      cv: "Descargar CV",
    },
    caseStudy: {
      problem: "El Problema",
      discovery: "Discovery",
      solution: "Solución",
      impact: "Impacto",
      ai: "IA Aplicada",
      tools: "Herramientas",
      backBtn: "← Volver",
    },
  },
  EN: {
    nav: {
      about: "About",
      work: "360° Design",
      contact: "Contact",
    },
    home: {
      role: "Senior Product Designer · UX/UI · Frontend",
      intro:
        "I combine product discovery, design systems and frontend development to create digital experiences with real impact.",
      cta: "View projects",
      ctaContact: "Get in touch",
    },
    about: {
      title: "Hi,\nI'm Nelson",
      subtitle: "Multidisciplinary designer: Cross Media, 3D, UX/UI & Frontend",
      bio: `I'm a designer passionate about creating visual and digital solutions that connect with people. Over the years I've held multiple roles that have shaped me into a flexible, curious and results-driven professional.\n\nI work with Product Discovery methodologies inspired by Marty Cagan and Teresa Torres, combining user research, Opportunity Solution Trees and impact metrics to ensure every design solves real problems.\n\nOutside work I stay active through swimming, and my family is my greatest source of inspiration. My colleagues describe me as social, committed and always ready to collaborate.`,
      skills: "Tools & Skills",
    },
    work: {
      title: "360° Design",
      viewCase: "View case study",
    },
    contact: {
      title: "Let's talk!",
      subtitle:
        "If you have questions, proposals or just want to say hi, don't hesitate to reach out.",
      linkedin: "LinkedIn",
      github: "GitHub",
      cv: "Download CV",
    },
    caseStudy: {
      problem: "The Problem",
      discovery: "Discovery",
      solution: "Solution",
      impact: "Impact",
      ai: "AI Applied",
      tools: "Tools",
      backBtn: "← Back",
    },
  },
  SV: {
    nav: {
      about: "Om mig",
      work: "360° Design",
      contact: "Kontakt",
    },
    home: {
      role: "Senior Product Designer · UX/UI · Frontend",
      intro:
        "Jag kombinerar product discovery, designsystem och frontendutveckling för att skapa digitala upplevelser med verkligt genomslag.",
      cta: "Se projekt",
      ctaContact: "Kontakta mig",
    },
    about: {
      title: "Hej,\njag är Nelson",
      subtitle: "Multikompetent designer: Cross Media, 3D, UX/UI & Frontend",
      bio: `Jag är en designer med passion för att skapa visuella och digitala lösningar som når fram till människor. Under åren har jag haft flera roller som format mig till en flexibel, nyfiken och lösningsorienterad person.\n\nJag arbetar med Product Discovery-metodiker inspirerade av Marty Cagan och Teresa Torres, och kombinerar användarforskning, Opportunity Solution Trees och påverkansmätningar för att säkerställa att varje design löser verkliga problem.\n\nPå fritiden håller jag mig aktiv genom simning, och min familj är min största inspirationskälla. Mina kollegor beskriver mig som social, engagerad och alltid redo att samarbeta.`,
      skills: "Verktyg & Skills",
    },
    work: {
      title: "360° Design",
      viewCase: "Se fallstudie",
    },
    contact: {
      title: "Låt oss prata!",
      subtitle:
        "Om du har frågor, förslag eller bara vill hälsa, tveka inte att kontakta mig.",
      linkedin: "LinkedIn",
      github: "GitHub",
      cv: "Ladda ner CV",
    },
    caseStudy: {
      problem: "Problemet",
      discovery: "Discovery",
      solution: "Lösning",
      impact: "Påverkan",
      ai: "AI Tillämpad",
      tools: "Verktyg",
      backBtn: "← Tillbaka",
    },
  },
};

export const LanguageProvider = ({ children }) => {
  const [lang, setLang] = useState("EN");
  const t = translations[lang];
  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLang = () => useContext(LanguageContext);
